#!/usr/bin/env bash
docker-compose -f src/main/docker/mysql.yml

